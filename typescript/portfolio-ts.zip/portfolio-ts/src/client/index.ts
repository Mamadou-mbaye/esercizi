const body: HTMLBodyElement = document.body as HTMLBodyElement;
const header: HTMLElement = document.getElementById("header") as HTMLElement;
const nav_links: HTMLElement = document.getElementById(
  "nav-links"
) as HTMLElement;
const menu: HTMLElement = document.querySelector("#menu") as HTMLElement;
const links: HTMLElement = document.querySelector("#links") as HTMLElement;
const handleMenu = (): void => {
  if (body.clientWidth < 768) {
    // Rimuove la classe "hidden" dal menu e aggiunge la classe "hidden" ai links
    menu.classList.remove("hidden");
    links.classList.add("hidden");
    nav_links.classList.remove("w-3/4");

    // Aggiunge un listener per l'evento click sul menu
    menu.addEventListener("click", toggleMenu);
  } else {
    // Ripristina lo stato normale
    header.classList.add("justify-between");
    header.classList.remove("flex-col");
    menu.classList.remove("justify-self-center");
    menu.classList.add("hidden");
    links.classList.remove("hidden");
    links.classList.remove("flex-col");
    nav_links.classList.add("w-3/4");
  }
};

const toggleMenu = (): void => {
  const headerClasses = ["flex-col", "justify-center", "h-64"];
  if (header.classList.contains("justify-between")) {
    menu.innerHTML = `<i class="fa-solid fa-xmark active:text-gray-400 hover:text-gray-300"></i>`;
    // Aggiunge le classi "flex-col" e "bg-white" al header
    header.classList.remove("justify-between");
    header.classList.add(...headerClasses);
    // Aggiunge la classe "justify-self-center" al menu
    menu.classList.add("justify-self-center");
    // Rimuove la classe "hidden" dai links e aggiungere la classe flex-col
    links.classList.remove("hidden");
    links.classList.add("flex-col");
  } else {
    menu.innerHTML = `<i class="fa-solid fa-bars"></i>`;
    header.classList.add("justify-between");
    header.classList.remove(...headerClasses);
    menu.classList.remove("justify-self-center");
    links.classList.add("hidden");
    links.classList.remove("flex-col");
  }
};

const info_content: HTMLDivElement = document.getElementById(
  "info-content"
) as HTMLDivElement;
const about: HTMLTitleElement = document.getElementById(
  "about"
) as HTMLTitleElement;
const portfolio: HTMLTitleElement = document.getElementById(
  "portfolio"
) as HTMLTitleElement;
const skills: HTMLTitleElement = document.getElementById(
  "skills"
) as HTMLTitleElement;
const tecnologies: HTMLTitleElement = document.getElementById(
  "tecnologies"
) as HTMLTitleElement;
const handleInfoContent = (): void => {
  about.addEventListener("click", () => {
    info_content.innerHTML = `<h4 class="text-xl mt-4 font-bold">My Journey</h4>
      <p class=" w-full p-0 m-0">I started my journey in web development 7 months ago and have since developed an understanding of both front-end and back-end technologies.</p>
      <hr class="w-3/4 mx-auto my-4">
      <h4 class="text-xl font-bold">Professional Experience</h4>
      <p class=" w-full p-0 m-0">During my journey, I have worked on various projects, from task management applications to personal portfolio websites. These experiences have honed my skills with various technologies. Additionally, I am currently completing an internship where I have worked on several key projects, further enhancing my skills in real-world scenarios.</p>
      <hr class="w-3/4 mx-auto my-4">
      <h4 class="text-xl font-bold">Beyond Coding</h4>
      <p class=" w-full p-0 m-0">When I'm not coding, I enjoy reading novels. It's a great way for me to unwind and immerse myself in different worlds and stories. I also explore new technologies. I believe in continuous learning and always strive to improve both personally and professionally.</p>`;
  });
  portfolio.addEventListener("click", () => {
    info_content.innerHTML = `<h4 class="text-xl mt-4 font-bold">Task Manager App</h4>
      <p>A web application for managing tasks, developed using HTML, CSS, and JavaScript.</p>
      <p><strong>Technologies</strong>: <br> HTML, CSS, JavaScript</p>
      <p><strong>Description</strong>:<br> I developed this application to manage and monitor daily tasks using HTML for structure, CSS for styling, and JavaScript for interaction logic. The tasks are stored locally in the browser using localStorage for persistence.</p>
      <p>This project is hosted on GitHub and can be accessed <a class="text-white hover:text-gray-400 italic" href="https://mamadou-mbaye.github.io/Tasks-List-js/" target="_blank">here</a>.</p>
      <a class="text-xl font-bold text-white hover:text-gray-400 cursor-pointer pt-3" href="https://github.com/Mamadou-mbaye/Tasks-List-js" target="_blank">GitHub Repository</a>
      
      <hr class="w-3/4 mx-auto my-4">
      <h4 class="text-xl font-bold">Task Manager with Java</h4>
      <p>A java application for task management.</p>
      <p><strong>Technologies</strong>:<br> Java</p>
      <p><strong>Description</strong>:<br> I developed this application using Java. The project includes features for adding, editing, and deleting tasks.</p>
      <a class="text-xl font-bold text-white hover:text-gray-400 cursor-pointer pt-3" href="https://github.com/Mamadou-mbaye/simple-task-manager" target="_blank">GitHub Repository</a>
      <hr class="w-3/4 mx-auto my-4">

      <h4 class="text-xl font-bold">Interactive Calculator</h4>
      <p>An interactive calculator developed using HTML, CSS, and JavaScript.</p>
      <p><strong>Technologies</strong>:<br> HTML, CSS, JavaScript</p>
      <p><strong>Description</strong>:<br> I created this interactive calculator application using HTML for structure, CSS for styling, and JavaScript for functionality. It allows users to perform basic arithmetic operations and displays results dynamically.</p>
      <p>This project is hosted on GitHub and can be accessed <a class="text-white hover:text-gray-400 italic" href="https://mamadou-mbaye.github.io/calcolatrice-interattiva/" target="_blank">here</a>.</p>
      <a class="text-xl font-bold text-white hover:text-gray-400 cursor-pointer pt-3" href="https://github.com/Mamadou-mbaye/calcolatrice-interattiva" target="_blank">GitHub Repository</a>
      `;
  });
  skills.addEventListener("click", () => {
    info_content.innerHTML = `
      <ul class=" list-none grid gap-4 mt-4">
                    <li>
                      <strong>JavaScript</strong>:<br> My primary programming language, which I use for both front-end and back-end development.
                    </li>
                    <hr class="w-3/4 mx-auto ">
                    <li>
                      <strong>HTML</strong>:<br> The foundation of web development, which I use to structure web pages. I learned HTML at the beginning of my web development journey.
                    </li>
                    <hr class="w-3/4 mx-auto ">
                    <li>
                      <strong>CSS</strong>:<br> I learned CSS along with HTML and have used it extensively in my projects.
                    </li>
                    <hr class="w-3/4 mx-auto ">
                    <li>
                      <strong>React.js</strong>:<br> My go-to library for building dynamic and responsive user interfaces.
                    </li>
                    <hr class="w-3/4 mx-auto ">
                    <li>
                      <strong>Java</strong>:<br> A utility-first CSS framework that I started using for this portfolio project out of curiosity. I learned Tailwind CSS on my own by following the official documentation and applying it in my projects.
                    </li>
                    <hr class="w-3/4 mx-auto ">
                    <li>
                      <strong>Tailwind CSS</strong>:<br> A utility-first CSS framework that I started using for this portfolio project. I learned Tailwind CSS on my own by following the official documentation and applying it in my projects.
                    </li>
                    <hr class="w-3/4 mx-auto ">
                    <li>
                      <strong>TypeScript</strong>:<br> A strongly typed superset of JavaScript that I began using recently. I taught myself TypeScript to improve the reliability and maintainability of my code.
                    </li>
                  </ul>`;
  });
  tecnologies.addEventListener("click", () => {
    info_content.innerHTML = `<ul class=" list-none grid gap-4 mt-4">
      <li>
        <strong>Node.js</strong>:<br> Used for building server-side applications. I have built several back-end services with Node.js and Express.js.
      </li>
      <hr class="w-3/4 mx-auto ">
      <li>
        <strong>Express.js</strong>:<br> A web application framework for Node.js that I use for creating APIs and handling server-side logic.
      </li>
      <hr class="w-3/4 mx-auto ">
      <li>
        <strong>MySQL</strong>:<br> My preferred database for handling relational data, which I have used in conjunction with Sequelize.
      </li>
      <hr class="w-3/4 mx-auto ">
      <li>
        <strong>Sequelize</strong>:<br> An ORM for Node.js that I use for managing database interactions in my projects.
      </li>
      <hr class="w-3/4 mx-auto ">
      <li>
        <strong>Git & GitHub</strong>:<br> Essential tools for version control and collaboration. I use Git for version control and GitHub for hosting my repositories.
      </li>
      <hr class="w-3/4 mx-auto ">
      <li>
        <strong>RESTful APIs</strong>:<br> I design and implement RESTful APIs to facilitate communication between the front-end and back-end of my applications.
      </li>
    </ul>`;
  });
};
handleInfoContent();

const area_form = document.getElementById("area-form") as HTMLFormElement;
const full_name = document.getElementById("full-name") as HTMLInputElement;
const email = document.getElementById("email") as HTMLInputElement;
const textarea = document.getElementById("textarea") as HTMLInputElement;
const submit_msg = document.getElementById("submit-msg") as HTMLButtonElement;

const isEmailValid = (email: string): boolean => {
  // Regex per validare un indirizzo email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const handleMessage = (): void => {
  submit_msg.addEventListener("click", (event) => {
    const full_name_value = full_name.value.trim();
    const email_value = email.value.trim();
    const textarea_value = textarea.value.trim();

    const msg_input = [full_name, email, textarea];

    const isFullNameValid = full_name_value !== "";
    const isEmailValidFlag = isEmailValid(email_value);
    const isTextareaValid = textarea_value !== "";
    event.preventDefault();
    if (!isFullNameValid || !isEmailValidFlag || !isTextareaValid) {
      msg_input.forEach((element) => {
        if (element.value.trim() === "") {
          element.classList.remove("bg-green-400");
          element.classList.add("bg-red-400");
        } else {
          element.classList.remove("bg-red-400");
          element.classList.add("bg-green-400");
        }
      });
      alert("Please enter valid values in all fields.");
    } else {
      alert("Your message has been sent successfully!");
    }
  });
};
const RegisterMsg = async (name: string, email: string, msg: string) => {
  area_form.addEventListener("submit", () => {});
  alert(`Fullname:${name} email:${email} message:${msg}`);
};
handleMessage();

document.addEventListener("DOMContentLoaded", () => {
  handleMenu();
window.history.pushState(portfolio, "https://modu/portfolio/")
});
window.addEventListener("resize", () => {
  handleMenu();
});