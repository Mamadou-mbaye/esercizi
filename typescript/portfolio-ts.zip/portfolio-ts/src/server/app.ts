import express,{Application} from 'express'
import path from 'path'
const app:Application = express()
const port = 3000



app.use(express.json())
app.get('/',(req,res)=>{
   res.sendFile(path.join(__dirname, '../../public/index.html'))
})
app.listen(port, ()=>{
    console.log(`App is listening on port ${port}...`)
})